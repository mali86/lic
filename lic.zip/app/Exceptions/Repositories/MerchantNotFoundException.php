<?php

namespace App\Exceptions\Repositories;

class MerchantNotFoundException extends \Exception
{
}