<?php

namespace App\Exceptions\Repositories;

class AreaBeingUsedException extends \Exception
{

}