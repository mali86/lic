<?php

namespace App\Exceptions\Repositories;

class CategoryBeingUsedException extends \Exception
{

}