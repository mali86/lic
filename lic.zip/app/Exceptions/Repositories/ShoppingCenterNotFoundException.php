<?php

namespace App\Exceptions\Repositories;

class ShoppingCenterNotFoundException extends \Exception
{

}