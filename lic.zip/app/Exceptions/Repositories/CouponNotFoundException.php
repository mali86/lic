<?php

namespace App\Exceptions\Repositories;

class CouponNotFoundException extends \Exception
{

}