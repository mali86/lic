<?php

namespace App\Exceptions\Repositories;

class CouponDateException extends \Exception
{

}