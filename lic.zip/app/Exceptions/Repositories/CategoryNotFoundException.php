<?php

namespace App\Exceptions\Repositories;

class CategoryNotFoundException extends \Exception
{

}