<?php

namespace App\Exceptions\Repositories;

class AreaNotFoundException extends \Exception
{

}