<?php

namespace App\Exceptions\Repositories;


class FileNotFoundException extends \Exception
{

}