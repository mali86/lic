<?php

namespace App\Exceptions\Repositories;

class ShoppingCenterBeingUsedException extends \Exception
{

}