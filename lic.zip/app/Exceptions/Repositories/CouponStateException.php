<?php

namespace App\Exceptions\Repositories;

class CouponStateException extends \Exception
{

}