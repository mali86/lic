<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ShoppingCenter extends Model
{
    //
}
